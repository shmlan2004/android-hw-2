package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       final EditText x = findViewById(R.id.editTextTextPersonName);
       final EditText z = findViewById(R.id.editTextTextPersonName3);
       final EditText y = findViewById(R.id.editTextTextPersonName4);
       final EditText a = findViewById(R.id.editTextTextPersonName5);
        Button CALCULATE = findViewById(R.id.button);

        CALCULATE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int x1 = Integer.parseInt(x.getText().toString());
                int x2 = Integer.parseInt(y.getText().toString());
                int z1 = Integer.parseInt(z.getText().toString());
                int z2 = Integer.parseInt(a.getText().toString());
                int num = x1 + z1 + x2 + z2;


                Toast.makeText(MainActivity.this,  num + "" , Toast.LENGTH_SHORT).show();

            }
        });
    }
}